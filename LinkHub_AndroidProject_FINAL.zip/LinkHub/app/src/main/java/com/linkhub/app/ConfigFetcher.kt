package com.linkhub.app

import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object ConfigFetcher {

    // ==========================================================
    // IMPORTANT: Yahan apni Google Sheet ki "Publish to web" CSV link daalein
    // File -> Share -> Publish to web -> CSV -> Publish, link copy karke yahan paste karein
    // ==========================================================
    private const val SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/1I840Fn7nKwnLCgP0LWgJ_gHqt7SORrraa08s17Cm5KE/export?format=csv&gid=0"

    // Current app version - ye number badalna sirf naya APK build karte waqt zaroori hai
    const val CURRENT_APP_VERSION = 1

    // Contact info dikhane ke liye agar sheet me na diya ho
    const val DEFAULT_CONTACT = "Contact karein: example@email.com"

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    interface Callback {
        fun onSuccess(config: AppConfig)
        fun onError(message: String)
    }

    fun fetchConfig(callback: Callback) {
        executor.execute {
            try {
                val url = URL(SHEET_CSV_URL)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val reader = BufferedReader(InputStreamReader(connection.inputStream))
                    val text = reader.readText()
                    reader.close()

                    val config = parseCsv(text)
                    mainHandler.post { callback.onSuccess(config) }
                } else {
                    mainHandler.post { callback.onError("Server error: $responseCode") }
                }
            } catch (e: Exception) {
                mainHandler.post { callback.onError(e.message ?: "Unknown error") }
            }
        }
    }

    /**
     * Expected CSV columns (header row required, exact order doesn't matter as long as
     * these column names exist): version, name, url, message, contact
     *
     * Only the FIRST row's "version" value is used as the app's current version.
     * Every row with a non-empty "name" and "url" becomes a clickable link card.
     */
    private fun parseCsv(csvText: String): AppConfig {
        val lines = csvText.split("\n").filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            return AppConfig(1, "", DEFAULT_CONTACT, emptyList())
        }

        val headers = parseCsvLine(lines[0]).map { it.trim().lowercase() }
        val versionIdx = headers.indexOf("version")
        val nameIdx = headers.indexOf("name")
        val urlIdx = headers.indexOf("url")
        val messageIdx = headers.indexOf("message")
        val contactIdx = headers.indexOf("contact")

        var version = 1
        var message = ""
        var contact = DEFAULT_CONTACT
        val links = mutableListOf<LinkItem>()

        for (i in 1 until lines.size) {
            val cols = parseCsvLine(lines[i])

            if (i == 1) {
                if (versionIdx in cols.indices) {
                    version = cols[versionIdx].trim().toIntOrNull() ?: 1
                }
                if (messageIdx in cols.indices && cols[messageIdx].isNotBlank()) {
                    message = cols[messageIdx].trim()
                }
                if (contactIdx in cols.indices && cols[contactIdx].isNotBlank()) {
                    contact = cols[contactIdx].trim()
                }
            }

            val name = if (nameIdx in cols.indices) cols[nameIdx].trim() else ""
            val url = if (urlIdx in cols.indices) cols[urlIdx].trim() else ""

            if (name.isNotBlank() && url.isNotBlank()) {
                links.add(LinkItem(name, url))
            }
        }

        return AppConfig(version, message, contact, links)
    }

    // Simple CSV line parser that handles quoted fields containing commas
    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> inQuotes = !inQuotes
                c == ',' && !inQuotes -> {
                    result.add(current.toString())
                    current.clear()
                }
                else -> current.append(c)
            }
            i++
        }
        result.add(current.toString())
        return result
    }
}
