package com.linkhub.app

data class LinkItem(
    val name: String,
    val url: String
)

data class AppConfig(
    val version: Int,
    val message: String,
    val contactInfo: String,
    val links: List<LinkItem>
)
