package com.linkhub.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var loadingLayout: LinearLayout
    private lateinit var updateLayout: LinearLayout
    private lateinit var errorLayout: LinearLayout
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var recyclerView: RecyclerView
    private lateinit var updateMessage: TextView
    private lateinit var errorMessage: TextView
    private lateinit var contactButton: Button
    private lateinit var retryButton: Button

    private var lastContactInfo: String = ConfigFetcher.DEFAULT_CONTACT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loadingLayout = findViewById(R.id.loadingLayout)
        updateLayout = findViewById(R.id.updateLayout)
        errorLayout = findViewById(R.id.errorLayout)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        recyclerView = findViewById(R.id.recyclerView)
        updateMessage = findViewById(R.id.updateMessage)
        errorMessage = findViewById(R.id.errorMessage)
        contactButton = findViewById(R.id.contactButton)
        retryButton = findViewById(R.id.retryButton)

        recyclerView.layoutManager = LinearLayoutManager(this)

        retryButton.setOnClickListener { loadData() }
        swipeRefresh.setOnRefreshListener { loadData() }

        contactButton.setOnClickListener {
            // Opens a share dialog with contact info so user can message/copy it easily
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_TEXT, lastContactInfo)
            startActivity(Intent.createChooser(shareIntent, "Contact"))
        }

        loadData()
    }

    private fun loadData() {
        showLoading()
        ConfigFetcher.fetchConfig(object : ConfigFetcher.Callback {
            override fun onSuccess(config: AppConfig) {
                swipeRefresh.isRefreshing = false
                lastContactInfo = config.contactInfo

                if (config.version > ConfigFetcher.CURRENT_APP_VERSION) {
                    showUpdateRequired(config.message, config.contactInfo)
                } else {
                    showLinks(config.links)
                }
            }

            override fun onError(message: String) {
                swipeRefresh.isRefreshing = false
                showError()
            }
        })
    }

    private fun showLoading() {
        loadingLayout.visibility = android.view.View.VISIBLE
        updateLayout.visibility = android.view.View.GONE
        errorLayout.visibility = android.view.View.GONE
        swipeRefresh.visibility = android.view.View.GONE
    }

    private fun showUpdateRequired(message: String, contact: String) {
        loadingLayout.visibility = android.view.View.GONE
        errorLayout.visibility = android.view.View.GONE
        swipeRefresh.visibility = android.view.View.GONE
        updateLayout.visibility = android.view.View.VISIBLE

        if (message.isNotBlank()) {
            updateMessage.text = message
        }
    }

    private fun showError() {
        loadingLayout.visibility = android.view.View.GONE
        updateLayout.visibility = android.view.View.GONE
        swipeRefresh.visibility = android.view.View.GONE
        errorLayout.visibility = android.view.View.VISIBLE
    }

    private fun showLinks(links: List<LinkItem>) {
        loadingLayout.visibility = android.view.View.GONE
        updateLayout.visibility = android.view.View.GONE
        errorLayout.visibility = android.view.View.GONE
        swipeRefresh.visibility = android.view.View.VISIBLE

        recyclerView.adapter = LinkAdapter(links) { item ->
            openLink(item.url)
        }
    }

    private fun openLink(url: String) {
        try {
            var finalUrl = url
            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                finalUrl = "https://$finalUrl"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(finalUrl))
            startActivity(intent)
        } catch (e: Exception) {
            // Silently ignore if no browser/app can handle it
        }
    }
}
