package com.linkhub.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class LinkAdapter(
    private val links: List<LinkItem>,
    private val onClick: (LinkItem) -> Unit
) : RecyclerView.Adapter<LinkAdapter.LinkViewHolder>() {

    class LinkViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nameText: TextView = view.findViewById(R.id.linkName)
        val urlText: TextView = view.findViewById(R.id.linkUrl)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): LinkViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_link, parent, false)
        return LinkViewHolder(view)
    }

    override fun onBindViewHolder(holder: LinkViewHolder, position: Int) {
        val item = links[position]
        holder.nameText.text = item.name
        holder.urlText.text = item.url
        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = links.size
}
